// Copyright 2004-present Facebook. All Rights Reserved.

package com.facebook.places;
@Deprecated
public class Places { }
